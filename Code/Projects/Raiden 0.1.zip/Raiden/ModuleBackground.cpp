#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleBackground.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleBackground::ModuleBackground()
{
	ground.x = 351;
	ground.y = 0;
	ground.w = 351;
	ground.h = 3265;

	background.x = 0;
	background.y = 0;
	background.w = 351;
	background.h = 3265;

	// Aqui van lo de les animations flag.pushBack({x,y,w,h})
	
}

ModuleBackground::~ModuleBackground(){}

bool ModuleBackground::Start(){
	LOG("Loading background assets");
	bool ret = true;
	graphics = App->textures->Load("Nivel_1_Tilemap.png");
	return ret;
}

update_status ModuleBackground::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, -3265 + SCREEN_HEIGHT, &background); // sea and sky
	
	App->render->Blit(graphics, 0, -3265 + SCREEN_HEIGHT, &ground);

	return UPDATE_CONTINUE;
}