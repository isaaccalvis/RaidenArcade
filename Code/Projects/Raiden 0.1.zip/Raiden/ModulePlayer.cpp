#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include <iostream>
// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModulePlayer::ModulePlayer(){
	position.x = 100;
	position.y = 220;

	idle.PushBack({83, 18, 26, 30});
	idle.speed = 0.2f;
	
	rightMov.PushBack({ 115,18,24,30 });

	leftMov.PushBack({ 52,18,24,30 });

}

ModulePlayer::~ModulePlayer(){}

bool ModulePlayer::Start(){
	LOG("Loading player textures");
	bool ret = true;
	graphics = App->textures->Load("NauPlayer.png");
	return ret;
}

update_status ModulePlayer::Update(){
	Animation* current_animation = &idle;

	int speed = 1;

	if(App->input->keyboard[SDL_SCANCODE_D] == 1){
		position.x += speed;
		current_animation = &rightMov;
	}
	if (App->input->keyboard[SDL_SCANCODE_A] == 1) {
		position.x -= speed;
		current_animation = &leftMov;
	}
	if (App->input->keyboard[SDL_SCANCODE_W] == 1) {
		position.y -= speed*4;
	}
	if (App->input->keyboard[SDL_SCANCODE_S] == 1) {
		position.y += speed*4;
	}
/*	if ((App->render->camera.y - App->render->camera.h) > (position.y)){
		position.y = (App->render->camera.y - App->render->camera.h);
	}
	std::cout << App->render->camera.y  << " :: " << position.y<< std::endl;
*/
		// Draw everything --------------------------------------
	SDL_Rect r = current_animation->GetCurrentFrame();

	App->render->Blit(graphics, position.x, position.y - r.h, &r);
	
	return UPDATE_CONTINUE;
}